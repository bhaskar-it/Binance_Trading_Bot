import streamlit as st
from binance.client import Client
from binance.exceptions import BinanceAPIException

# Page Config
st.set_page_config(page_title="🚀 Binance Futures Trading Bot", layout="centered")

st.title("🚀 Binance Futures Trading Bot (Testnet)")
st.markdown("Trade on the Binance Futures Testnet with a user-friendly interface.")

# Input Form
with st.form("order_form"):
    st.subheader("🔑 API Credentials")
    api_key = st.text_input("API Key", type="password")
    api_secret = st.text_input("API Secret", type="password")

    st.subheader("📈 Trade Settings")
    symbol = st.text_input("Symbol (e.g., BTCUSDT)", value="BTCUSDT")
    side = st.selectbox("Order Side", ["BUY", "SELL"])
    order_type = st.selectbox("Order Type", ["MARKET", "LIMIT"])
    quantity = st.number_input("Quantity", min_value=0.001, step=0.001, value=0.01)

    price = None
    if order_type == "LIMIT":
        price = st.number_input("Limit Price (required for LIMIT)", min_value=0.0, value=60000.0)

    submit = st.form_submit_button("Place Order")

# Handle Order Submission
if submit:
    if not api_key or not api_secret:
        st.error("Please enter your API credentials.")
    else:
        try:
            client = Client(api_key, api_secret, testnet=True)
            client.API_URL = 'https://testnet.binancefuture.com/fapi'

            params = {
                "symbol": symbol.upper(),
                "side": side.upper(),
                "type": order_type.upper(),
                "quantity": quantity
            }
            if order_type == "LIMIT":
                params["price"] = price
                params["timeInForce"] = "GTC"

            st.info("⏳ Placing order...")
            order = client.futures_create_order(**params)

            st.success("✅ Order placed successfully!")
            st.json(order)

        except BinanceAPIException as e:
            st.error(f"🚫 Binance API Error: {e.message}")
        except Exception as e:
            st.error(f"❌ Unexpected Error: {str(e)}")
