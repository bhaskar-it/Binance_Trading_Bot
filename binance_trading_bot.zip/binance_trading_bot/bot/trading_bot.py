import logging
from binance.client import Client
from binance.enums import *

class BasicBot:
    def __init__(self, api_key, api_secret):
        self.client = Client(api_key, api_secret, testnet=True)
        self.client.FUTURES_URL = "https://testnet.binancefuture.com"
        self.client.API_URL = self.client.FUTURES_URL
        logging.basicConfig(filename='trade.log', level=logging.INFO, format='%(asctime)s %(message)s')

    def place_order(self, symbol, side, order_type, quantity, price=None):
        try:
            if order_type == 'MARKET':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == 'BUY' else SIDE_SELL,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            elif order_type == 'LIMIT':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == 'BUY' else SIDE_SELL,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce=TIME_IN_FORCE_GTC,
                    quantity=quantity,
                    price=price
                )
            logging.info(f"Order placed: {order}")
            print("Order executed:", order)
        except Exception as e:
            logging.error(f"Order failed: {str(e)}")
            print("Error placing order:", str(e))
