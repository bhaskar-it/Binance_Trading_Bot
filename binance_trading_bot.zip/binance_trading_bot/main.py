import argparse
from bot.trading_bot import BasicBot

def main():
    parser = argparse.ArgumentParser(description="Simple Binance Futures Trading Bot")
    parser.add_argument('--api_key', type=str, required=True, help='Binance API Key')
    parser.add_argument('--api_secret', type=str, required=True, help='Binance API Secret')
    parser.add_argument('--side', type=str, choices=['BUY', 'SELL'], required=True, help='Order side')
    parser.add_argument('--type', type=str, choices=['MARKET', 'LIMIT'], required=True, help='Order type')
    parser.add_argument('--symbol', type=str, default='BTCUSDT', help='Trading symbol')
    parser.add_argument('--quantity', type=float, required=True, help='Order quantity')
    parser.add_argument('--price', type=float, help='Limit price (required if type is LIMIT)')

    args = parser.parse_args()
    bot = BasicBot(args.api_key, args.api_secret)
    bot.place_order(args.symbol, args.side, args.type, args.quantity, args.price)

if __name__ == "__main__":
    main()
